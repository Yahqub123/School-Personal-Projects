#ifndef ENT_ITEMS_H
#define ENT_ITEMS_H
#include "Game.h"
#include "Movie.h"
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Ent_items
{
    public:
    void add_Ent_item();
    void edit_Ent_item();
    void delete_Ent_item();
    int Find_Ent_item();
    void Print_list_of_Entitem();
    void Print_entitem_info(int found);
    void ListOfAll_Loans_for_specificentitem();
    vector<Game> Games;
    vector<Movie> Movie_List;
};
#endif
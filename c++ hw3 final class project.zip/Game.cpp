#include "Game.h"
#include <iostream>
using namespace std;

Game::Game(){}
Game::Game(string a,string b,string c,string d,string e,double f,double g,int i,double j,string k ,int l):Ent_item(i,j,k,l)
{
    Rating=a;
    Genre=b;
    Title=c;
    Release_date=d;
    Company_Name=e;
    Rental_Cost=f;
    Replacement_Cost=g;
}

void Game::setRating(string rating)
{
    Rating=rating;
}

void Game::setGenre(string genre)
{
    Genre=genre;
}

void Game::setTitle(string title)
{
    Title=title;
}

void Game::setRelease_date(string release_date)
{
    Release_date=release_date;
}

void Game::setCompany_Name(string company_Name)
{
    Company_Name=company_Name;
}

void Game::setRental_Cost(double rental_Cost)
{
    Rental_Cost=rental_Cost;
}

void Game::setReplacement_Cost(double replacement_Cost)
{
    Replacement_Cost=replacement_Cost;
}

string Game::getRating()
{
    return Rating;
}

string Game::getGenre()
{
    return Genre;
}

string Game::getTitle()
{
    return Title;
}

string Game::getRelease_date()
{
    return Release_date;
}

string Game::getCompany_Name()
{
    return Company_Name;
}

double Game::getRental_Cost()
{
    return Rental_Cost;
}

double Game::getReplacement_Cost()
{
    return Replacement_Cost;
}

void Game::printitem()
{
    Ent_item::printitem();
}
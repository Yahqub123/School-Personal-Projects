#ifndef LOAN_H
#define LOAN_H
#include <string>
using namespace std;

class Loan
{
    public:
    Loan();
    Loan(int loanID, int movieID, int customerID, string dueDate, double dueTime, string status);
    
    void Set_LoanID(int loanID);
    int get_LoanID();
    
    void Set_MovieID(int movieID);
    int get_MovieID();
    
    void Set_CustomerID(int customerID);
    int get_CustomerID();
    
    void Set_DueDate(string dueDate);
    string get_DueDate();
    
    void Set_DueTime(double dueTime);
    double get_DueTime();
    
    void Set_Status(string status);
    string get_Status();
    
    private:
    int LoanID;
    int MovieID;
    int CustomerID;
    string DueDate;
    double DueTime; 
    string Status;
};
#endif
#include "Customer.h"
#include <string>
using namespace std;

Customer::Customer(){}
Customer::Customer(int CustomerId, long int CreditCardNum, string CustomerName, string CreditCardExpDate, int CreditCardValKey, unsigned int NumOfMoviesActive)
{
    Customer_Id=CustomerId;
    Credit_CardNum=CreditCardNum;
    Customer_Name=CustomerName;
    Credit_Card_ExpDate=CreditCardExpDate;
    Credit_Card_ValKey=CreditCardValKey;
    Num_Of_Movies_Active=NumOfMoviesActive;
}

void Customer:: Set_CustomerId(int CustomerId)
{
    Customer_Id=CustomerId;
}

void Customer:: Set_CreditCardNum(long int CreditCardNum)
{
    Credit_CardNum=CreditCardNum;
}

void Customer:: Set_CustomerName(string CustomerName)
{
    Customer_Name=CustomerName;
}

void Customer:: Set_CreditCardExpDate(string CreditCardExpDate)
{
    Credit_Card_ExpDate=CreditCardExpDate;
}

void Customer:: Set_CreditCardValKey(int CreditCardValKey)
{
    Credit_Card_ValKey=CreditCardValKey;
}

void Customer:: Set_NumOfMoviesActive(unsigned int NumOfMoviesActive)
{
    Num_Of_Movies_Active=NumOfMoviesActive;
}

int  Customer::get_CustomerId()
{
    return Customer_Id;
}

long int Customer::get_CreditCardNum()
{
    return Credit_CardNum;
}

string Customer::get_CustomerName()
{
    return Customer_Name;
}

string Customer::get_CreditCardExpDate()
{
    return Credit_Card_ExpDate;
}

int Customer::get_CreditCardValKey()
{
    return Credit_Card_ValKey;
}

int Customer::get_NumOfMoviesActive()
{
    return Num_Of_Movies_Active;
}
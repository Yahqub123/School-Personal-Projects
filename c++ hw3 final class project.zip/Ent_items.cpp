#include "Ent_items.h"
#include <iostream>
#include <string>
using namespace std;

void Ent_items::add_Ent_item()
{
    int choice;
    cout<<"Which Entertainment item are you trying to add?\n";
    cout<<"Enter 1 to add a 'GAME' Entertainment item\n";
    cout<<"Enter 2 to add a 'MOVIE' Entertainment item\n";
    cin>>choice;
    if(choice==1)
    {
        int ID;
        double cost;
        string status;
        int period;
        string Rating;
        string Genre;
        string Title;
        string Release_date;
        string Company_Name;
        double Rental_Cost;
        double Replacement_Cost;
        cout<<"What is the ID of the GAME the you are tring to add?\n";
        cin>>ID;
        
        cout<<"What is the COST of Game you are tring to add?\n";
        cin>>cost;
        
        cout<<"What is the STATUS of Game you are tring to add?(In, out, lost)\n";
        cin.ignore();
        cin>>status;
        
        cout<<"What is the LOAN PERIOD of Game you are tring to add?(48 hours max)\n";
        cin>>period;
        
        cout<<"What is the RATING of Game you are tring to add?\n";
        cin.ignore();
        getline(cin,Rating);
        
        cout<<"What is the Genre of Game you are tring to add?\n";
        getline(cin,Genre);
        
        cout<<"What is the Title of Game you are tring to add?\n";
        getline(cin,Title);
        
        cout<<"What is the Release_date of Game you are tring to add?\n";
        getline(cin,Release_date);
        
        cout<<"What is the Company_Name of Game you are tring to add?\n";
        getline(cin,Company_Name);
        
        cout<<"What is the Rental_Cost of Game you are tring to add?\n";
        cin>>Rental_Cost;
        
        cout<<"What is the Replacement_Cost of Game you are tring to add?\n";
        cin>>Replacement_Cost;
        
        Game ob(Rating,Genre,Title,Release_date,Company_Name,Rental_Cost,Replacement_Cost,ID,cost,status,period);
        Games.push_back(ob);
    }
    else if(choice==2)
    {
        unsigned int count;//Accepts num of movies to be added to the Movie_List
        int ID;
        double cost;
        string status;
        int period;
        string Title;
        string ReleaseDate;
        string Rating;
        double Duration;
        float RentalCost;
        float ReplacementCost;
        cout<<"How many Movies are you trying to add to the list of movies?\n";
        cin>>count;
        for(int i=0; i<count; i++)
        {
            cout<<endl;
            cout<< "Enter the information for Movie "<< i+1 <<":\n";
            cout<<"What is the ID of the Movie that you are tring to add?\n";
            cin>>ID;
        
            cout<<"What is the COST of the Movie you are tring to add?\n";
            cin>>cost;
        
            cout<<"What is the STATUS of the Movie you are tring to add?(In, out, lost)\n";
            cin.ignore();
            cin>>status;
        
            cout<<"What is the LOAN PERIOD of Movie you are tring to add?(24 hours max)\n";
            cin>>period;
            
            cout<< "What is the TITLE of the Movie that you wish to add? \n";
            cin.ignore();
            getline(cin,Title);
            cout<< "What is the Movie's Release Date? (mm/yyyy) \n";
            cin.ignore();
            getline(cin,ReleaseDate);
            cout<< "What is the Movie's rating? \n";
            getline(cin,Rating);
            cout<< "What is the Movie's Duration?(hh.mm) \n";
            cin>>Duration;
            cout<< "What is the Movie's Rental Cost? ($dd.cc)\n$";
            cin>>RentalCost;
            cout<< "What is the Movie's Replacement Cost? ($dd.cc)\n$";
            cin>>ReplacementCost;
            
            Movie ob = {Title, ReleaseDate, Rating, Duration, RentalCost, ReplacementCost,ID,cost,status,period};
            Movie_List.push_back(ob);
        }
    }
}

void Ent_items::edit_Ent_item()
{
    int choice;
    cout<<"Which Entertainment item are you trying to EDIT?\n";
    cout<<"Enter 1 to edit a 'GAME' Entertainment item\n";
    cout<<"Enter 2 to edit a 'MOVIE' Entertainment item\n";
    cin>>choice;
    if(choice==1)
    {
        int option;
        int ID;
        double cost;
        string status;
        int period;
        string Rating;
        string Genre;
        string Title;
        string Release_date;
        string Company_Name;
        double Rental_Cost;
        double Replacement_Cost;
        cout<<"What is the ID of Game that you wish to edit it's information?\n";
        cin>>ID;
        for(int i=0; i<Games.size(); i++)
        {
                if(ID==Games.at(i).get_id())
                {
                   cout<<"what would you like to edit about this Game?\n";
                   cout<<"Enter 1 to edit Game Id"<<endl;
                   cout<<"Enter 2 to edit Game cost"<<endl;
                   cout<<"Enter 3 to edit Game status"<<endl;
                   cout<<"Enter 4 to edit Game Loan period"<<endl;
                   cout<<"Enter 5 to edit Game Rating"<<endl;
                   cout<<"Enter 6 to edit Game Genre"<<endl;
                   cout<<"Enter 7 to edit Game Title"<<endl;
                   cout<<"Enter 8 to edit Game Release_date"<<endl;
                   cout<<"Enter 9 to edit Game Company_Name"<<endl;
                   cout<<"Enter 10 to edit Game Rental_Cost"<<endl;
                   cout<<"Enter 11 to edit Game Replacement_Cost"<<endl;
                   cin>>option;
                   if(option==1)
                   {
                        cout<<"What is the new ID of the GAME the you are tring to edit?\n";
                        cin>>ID;
                        Games.at(i).set_id(ID);
                   }
                   else if(option==2)
                   {
                       cout<<"What is the new COST of Game you are tring to edit?\n";
                       cin>>cost;
                       Games.at(i).set_cost(cost);
                   }
                   else if(option==3)
                   {
                       cout<<"What is the new STATUS of the game you are tring to edit?(In, out, lost)\n";
                        cin.ignore();
                       cin>>status;
                       Games.at(i).set_status(status);
                   }
                   else if(option==4)
                   {
                        cout<<"What is the new LOAN PERIOD of game you are tring to edit?(24 hours max)\n";
                        cin>>period;
                       Games.at(i).set_period(period);
                   }
                   
                   else if(option==5)
                   {
                        cout<<"What is the new RATING of Game you are tring to edit?\n";
                        cin.ignore();
                        getline(cin,Rating);
                        Games.at(i).setRating(Rating);
                   }
                   else if(option==6)
                   {
                        cout<<"What is the new Genre of Game you are tring to edit?\n";
                        getline(cin,Genre);
                        Games.at(i).setGenre(Genre);
                   }
                   else if(option==7)
                   {
                       cout<<"What is the new Title of Game you are tring to edit?\n";
                        getline(cin,Title);
                        Games.at(i).setTitle(Title);
                   }
                  else if(option==8)
                  {
                    cout<<"What is the new Release_date of Game you are tring to edit?\n";
                    getline(cin,Release_date);
                    Games.at(i).setRelease_date(Release_date);
                  }
                  else if(option==9)
                  {
                        cout<<"What is the new Company_Name of Game you are tring to edit?\n";
                        getline(cin,Company_Name);
                        Games.at(i).setCompany_Name(Company_Name);
                  }
                  else if(option==10)
                  {
                        cout<<"What is the new Rental_Cost of Game you are tring to edit?\n";
                        cin>>Rental_Cost;
                        Games.at(i).setRental_Cost(Rental_Cost);
                  }
                  else if(option==11)
                  {
                        cout<<"What is the new Replacement_Cost of Game you are tring to edit?\n";
                        cin>>Replacement_Cost;
                        Games.at(i).setReplacement_Cost(Replacement_Cost);
                  }
                }
        }
    }
    else if(choice==2)
    {
        int num,edit;
        int ID;
        double cost;
        string status;
        int period;
        string Title;
        string ReleaseDate;
        string Rating;
        double Duration;
        float RentalCost;
        float ReplacementCost;
        cout<< "Which Movie would you like to edit its information?(Enter INTEGER digits only. 1,2,3....e.t.c) \n";
        cin>> num;
        if(num>0){
        num=num-1;//reduced the size because vectors start from 0 not 1.
        }
        else if(num<0){
        cout<<"Invalid input. Only POSITIVE integers are acceptable.\n";
        }
        
        for(int i=0; i<Movie_List.size(); i++)
        {
            if(i==num)
            {
                cout<<"What would you like to edit about Movie " << i+1 <<"?\n";
                cout<<"Enter 1 to edit movie Id"<<endl;
                cout<<"Enter 2 to edit movie cost"<<endl;
                cout<<"Enter 3 to edit movie status"<<endl;
                cout<<"Enter 4 to edit movie Loan period"<<endl;
                cout<<"Enter 5 to EDIT Movie's Title:\n";
                cout<<"Enter 6 to EDIT Movie's Release Date: (mm/yyyy)\n";
                cout<<"Enter 7 to EDIT Movie's rating?\n";
                cout<<"Enter 8 to EDIT Movie's Duration?(hh.mm)\n";
                cout<<"Enter 9 to EDIT Movie's Rental Cost? ($dd.cc)\n";
                cout<<"Enter 10 to EDIT Movie's Replacement Cost? ($dd.cc)\n";
                cin.ignore();
                cin>> edit;
                switch(edit)
                {
                    case 1:
                    {
                        cout<<"What is the NEW ID of the Movie that you are tring to edit?\n";
                        cin>>ID;
                        Movie_List.at(i).set_id(ID);
                        break;
                    }
                    case 2:
                    {
                        cout<<"What is the new COST of the Movie you are tring to edit?\n";
                        cin>>cost;
                        Movie_List.at(i).set_cost(cost);
                        break;
                    }
                    case 3:
                    {
                        cout<<"What is the new STATUS of the Movie you are tring to edit?(In, out, lost)\n";
                        cin.ignore();
                        cin>>status;
                        Movie_List.at(i).set_status(status);
                        break;
                    }
                    case 4:
                    {
                        cout<<"What is the new LOAN PERIOD of Movie you are tring to edit?(24 hours max)\n";
                        cin>>period;
                        Movie_List.at(i).set_period(period);
                        break;
                    }
                    case 5:
                    {
                        cout<<"Enter Movies's NEW TITLE: \n";
                        cin.ignore();
                        getline(cin,Title);
                        Movie_List.at(i).set_Title(Title);
                        break;
                    }
                    
                    case 6:
                    {
                        cout<< "Enter Movie's NEW Release Date? (mm/yyyy): \n";
                        cin.ignore();
                        getline(cin,ReleaseDate);
                        Movie_List.at(i).set_Release_Date(ReleaseDate);
                        break;
                    }
                    
                    case 7:
                    {
                        cout<< "Enter Movie's NEW rating:\n";
                        cin.ignore();
                        getline(cin,Rating);
                        Movie_List.at(i).set_Rating(Rating);
                        break;
                    }
                    
                    case 8:
                    {
                        cout<< "Enter Movie's NEW Duration: (hh.mm)\n";
                        cin>>Duration;
                        Movie_List.at(i).set_Duration(Duration);
                        break;
                    }
                    
                    case 9:
                    {
                        cout<< "Enter Movie's NEW Rental Cost? ($dd.cc):\n";
                        cin>>RentalCost;
                        Movie_List.at(i).set_Rental_Cost(RentalCost);
                        break;
                    }
                    
                    case 10:
                    {
                        cout<<"Enter Movie's NEW Replacement Cost ($dd.cc)\n";
                        cin>>ReplacementCost;
                        Movie_List.at(i).set_Replacement_Cost(ReplacementCost);
                        break;
                    }
                }
            }
        }
        
        if(num+1>Movie_List.size()){
        cout<<"Movie Not found!\n";    
        }
    }
}

void Ent_items::delete_Ent_item()
{
    int choice;
    int ID;
    cout<<"Which Entertainment item are you trying to delete?\n";
    cout<<"Enter 1 to delete a 'GAME' Entertainment item\n";
    cout<<"Enter 2 to delete a 'MOVIE' Entertainment item\n";
    cin>>choice;
    if(choice==1)
    {
        cout<<"What's the Id of the movie you want to delete its info?\n";
        cin>>ID;
        for(int i=0; i<Games.size(); i++)
        {
            if(ID==Games.at(i).get_id())
            {
                Games.erase(Games.begin()+ i);
            }
        }
    }
    else if(choice==2)
    {
         int Num;
        cout<< "Which Movie would you would like to Delete Its Information? (Enter INTEGER digits only. 1,2,3....e.t.c): \n";
        cin.ignore();
        cin>>Num;
        if(Num>0){
            Num=Num - 1;
        }
        else if(Num<0){
            cout<<"Invalid input. Only POSITIVE integers are acceptable.\n";
        }
        for(int i=0; i<Movie_List.size(); i++)
        {
            if(Num==i)
            {
                Movie_List.erase(Movie_List.begin()+ i);
            }
        }
        if(Num+1 > Movie_List.size())
        {
            cout<<"Movie " <<Num + 1<<" does not exist in the list of Movies\n";
            cout<<"There are only "<< Movie_List.size() << " Movies in the List.\n";
        }
    }
}

int Ent_items::Find_Ent_item(){return 0;}
void Ent_items::Print_list_of_Entitem(){
    int choice;
    cout<<"Enter 1 to see game info\n";
    cout<<"Enter 2 to see movie info\n";
}
void Ent_items::Print_entitem_info(int found){}
void Ent_items::ListOfAll_Loans_for_specificentitem(){}

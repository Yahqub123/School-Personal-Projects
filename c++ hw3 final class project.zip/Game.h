#ifndef GAME_H
#define GAME_H
#include "Ent_item.h"
#include <string>
using namespace std;

class Game: public Ent_item
{
    public:
    Game();//default
    Game(string,string,string,string,string,double,double,int,double,string,int);//paramitized constructor
    
    void setRating(string rating);
    void setGenre(string genre);
    void setTitle(string title);
    void setRelease_date(string release_date);
    void setCompany_Name(string company_Name);
    void setRental_Cost(double rental_Cost);
    void setReplacement_Cost(double replacement_Cost);
    
    string getRating();
    string getGenre();
    string getTitle();
    string getRelease_date();
    string getCompany_Name();
    double getRental_Cost();
    double getReplacement_Cost();
    void printitem();
    
    private:
    string Rating;
    string Genre;
    string Title;
    string Release_date;
    string Company_Name;
    double Rental_Cost;
    double Replacement_Cost;
};
#endif



/* Name: Yahqub Oyebola
 Course: CSCE 1040
 HOMEWORK 2.
 */
 
 
#include "Customer.h" 
#include "Movie.h"
#include "Loan.h"
#include "Customers.h"
#include "Movies.h"
#include "Loans.h"
#include <string>
#include <vector>
#include <iostream>
#include<fstream>
using namespace std;

int main()
{
    unsigned int choice=0;
    unsigned int choice1;//choice for CUSTOMER
    unsigned int choice2;//choice for MOVIE
    unsigned int choice3;//choice for LOAN
    char ans;
    cout<<"Enter 1 to deal with CUSTOMER INFORMATION\n";
    cout<<"Enter 2 to deal with MOVIE INFORMATION\n";
    cout<<"Enter 3 to deal with LOAN INFORMATION\n";
    cout<<"Enter 4 to quit.\n";
    cin>> choice;
    Customers ob;//object to call our cutomers functions
    Movies ob2;//object to call our movies functions.
    Loans ob3;//object to call our loans functions.
    ofstream fin("GreenBoxData.txt");
    while(choice!=4)
    {
        if(choice==1)
        {
            cout<<endl<<"What would you like to do to the CUSTOMER INFORMATION? \n";
            cout<<"Enter 1 to Add_customer: \n";
            cout<<"Enter 2 to Edit_customer: \n";
            cout<<"Enter 3 to Delete_customer: \n";
            cout<<"Enter 4 to Find_Customer: \n";
            cout<<"Enter 5 to Print_Customer_List: \n";
            cout<<"Enter 6 to Print the information of a particular customer: \n";
            cout<<"Enter 7 to see the List Of All Customers that loaned a Movie()\n";
            cout<<"Enter 8 to see the list of loans by a particular customer: \n";
            cout<<"Enter 9 to see a list of loans for all Customers\n";
            cout<<"Enter 0 to quit!\n";
            cin>>choice1;
            while(choice1 != 0 && choice1 < 10)
            {
                if(choice1==1)
                {
                    ob.Add_customer();
                }
                if(choice1==2)
                {
                    ob.Edit_customer();
                }
                if(choice1==3)
                {
                    ob.Delete_customer();
                }
                if(choice1==4)
                {
                    ob.Find_Customer();
                }
                if(choice1==5)
                {
                    ob.Print_Customer_List();
                }
                if(choice1==6)
                {
                    ob.Print_CustomerInfo(ob.Find_Customer());
                }
                if(choice1==7)
                {
                    ob.ListOfAll_LoansForMovie();
                }
                if(choice1==8)
                {
                    ob.ListOfAll_LoansForcustomer();
                }
                if(choice1==9)
                {
                    ob.ListOfLoansForAllCustomers();
                }
                
                cout<<endl<<"What ELSE would you like to do to the CUSTOMER INFORMATION? \n";
                cout<<"Enter 1 to Add_customer: \n";
                cout<<"Enter 2 to Edit_customer: \n";
                cout<<"Enter 3 to Delete_customer: \n";
                cout<<"Enter 4 to Find_Customer: \n";
                cout<<"Enter 5 to Print_Customer_List: \n";
                cout<<"Enter 6 to Print the information of a particular customer: \n";
                cout<<"Enter 7 to see the List Of All Customers that loaned a Movie()\n";
                cout<<"Enter 8 to see the list of movies loaned by a customer: \n";
                cout<<"Enter 9 to see a list of loans for all Customers\n";
                cout<<"Enter 0 to quit!\n";
                cin>>choice1;
            }
        }
        
        if(choice==2)
        {
            cout<<endl<<"What would you like to do to the MOVIE INFORMATION? \n";
            cout<<"Enter 1 to Add Movie: \n";
            cout<<"Enter 2 to Edit_Movie: \n";
            cout<<"Enter 3 to Delete_Movie: \n";
            cout<<"Enter 4 to Find_Movie: \n";
            cout<<"Enter 5 to Print_Movie_List: \n";
            cout<<"Enter 6 to Print the information of a particular Movie: \n";
            cout<<"Enter 7 to see the list of all Loans for a particular Movie\n";
            cout<<"Enter 8 to see the list of movies loaned by a customer: \n";
            cout<<"Enter 9 to see a list of all movie loans\n";
            cout<<"Enter 0 to quit!!\n";
            cin>>choice2;

            
            while(choice2 != 0 && choice2 < 10)
            {
                if(choice2==1)
                {
                    ob2.AddMovie(fin);
                }
                
                if(choice2==2)
                {
                    ob2.EditMovie();
                }
                if(choice2==3)
                {
                    fin.clear();
                    ob2.DeleteMovie();
                  /*ob2.writetofile(fin);
                    ob1.writetofile(fin);
                    ob3.writetofile(fin);*/
                   
                }
                if(choice2==4)
                {
                    ob2.FindMovie();
                }
                if(choice2==5)
                {
                    ob2.PrintMovieList();
                }
                if(choice2==6)
                {
                    ob2.PrintMovieInfo(ob2.FindMovie());
                }
                if(choice2==7)
                {
                    ob2.ListOfAll_LoansForMovie();
                }
                if(choice2==8)
                {
                    ob2.ListOfAllMovieLoansForcustomer();
                }
                if(choice2==9)
                {
                    ob2.ListOfAllMovieLoans();
                }
                
                cout<<endl<<"What ELSE would you like to do to the MOVIE INFORMATION? \n";
                cout<<"Enter 1 to Add Movie: \n";
                cout<<"Enter 2 to Edit_Movie: \n";
                cout<<"Enter 3 to Delete_Movie: \n";
                cout<<"Enter 4 to Find_Movie: \n";
                cout<<"Enter 5 to Print_Movie_List: \n";
                cout<<"Enter 6 to Print the information of a particular Movie: \n";
                cout<<"Enter 7 to see the list of all Loans for a particular Movie\n";
                cout<<"Enter 8 to see the list of movies loaned by a customer: \n";
                cout<<"Enter 9 to see a list of all movie loans\n";
                cout<<"Enter 0 to quit!!\n";
                cin>> choice2;
            }
        }
        
        if(choice==3)
        {
            cout<<endl<<"What would you like to do to the LOAN INFORMATION? \n";
            cout<<"Enter 1 to Add Loan: \n";
            cout<<"Enter 2 to Edit_LOAN: \n";
            cout<<"Enter 3 to Delete_loan: \n";
            cout<<"Enter 4 to Find_loan: \n";
            cout<<"Enter 5 to Print_loan_List: \n";
            cout<<"Enter 6 to Print the information of a particular loan: \n";
            cout<<"Enter 7 to see the list of all Loans for a particular Movie\n";
            cout<<"Enter 8 to see the list of movies loaned by a particular customer: \n";
            cout<<"Enter 9 to see a list of all loans\n";
            cout<<"Enter 0 to quit!!\n";
            cin>>choice3;
           
            
            while(choice3 != 0 && choice3 < 10)
            {
                if(choice3==1)
                {
                    ob3.AddLoan(ob, ob2);
                }
                if(choice3==2)
                {
                    ob3.EditLoan(ob, ob2);
                }
                if(choice3==3)
                {
                    ob3.DeleteLoan(ob, ob2);
                }
                if(choice3==4)
                {
                    ob3.FindLoan();
                }
                if(choice3==5)
                {
                    ob3.PrintLoanList();
                }
                if(choice3==6)
                {
                    ob3.PrintLoanInfo(ob3.FindLoan());
                }
                if(choice3==7)
                {
                    ob3.ListOfAll_LoansForMovie();
                }
                if(choice3==8)
                {
                    ob3.ListOfAll_LoansForcustomer();
                }
                if(choice3==9)
                {
                    ob3.ListOfAllLoans();
                }
                
                cout<<endl<<"What ELSE would you like to do to the LOAN INFORMATION? \n";
                cout<<"Enter 1 to Add Loan: \n";
                cout<<"Enter 2 to Edit_LOAN: \n";
                cout<<"Enter 3 to Delete_loan: \n";
                cout<<"Enter 4 to Find_loan: \n";
                cout<<"Enter 5 to Print_loan_List: \n";
                cout<<"Enter 6 to Print the information of a particular loan: \n";
                cout<<"Enter 7 to see the list of all Loans for a particular Movie\n";
                cout<<"Enter 8 to see the list of movies loaned by a particular customer: \n";
                cout<<"Enter 9 to see a list of all loans\n";
                cout<<"Enter 0 to quit!!\n";
                cin>>choice3;
            }
        }
        
        if(choice>4)
        {
            cout<<endl<<"Invalid input!!..Choice can only have the following options:\n";
            cout<<"Enter 1 to deal with CUSTOMER INFORMATION\n";
            cout<<"Enter 2 to deal with MOVIE INFORMATION\n";
            cout<<"Enter 3 to deal with LOAN INFORMATION\n";
            cout<<"Enter 4 to quit.\n";
            cout<<"Enter a new Choice\n";
            cin>>choice;
        }
        
        if(choice>0 && choice<=4)
        cout<<endl<<"What ELSE would you like to do to the program?\n";
        cout<<"Enter 1 to deal with CUSTOMER INFORMATION\n";
        cout<<"Enter 2 to deal with MOVIE INFORMATION\n";
        cout<<"Enter 3 to deal with LOAN INFORMATION\n";
        cout<<"Enter 4 to quit.\n";
        cin>>choice;
    }
    
}


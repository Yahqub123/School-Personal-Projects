#ifndef MOVIE_H
#define MOVIE_H
#include <iostream>
#include <string>
using namespace std;
class Movie
{
    public:
    Movie();
    Movie(int Movie_iD, string title, string releaseDate, string rating, double duration, float rentalCost, float replacementCost);
    
    void set_Movie_ID(int Movie_iD);
    void set_Title(string title);
    void set_Release_Date(string releaseDate);
    void set_Rating(string rating);
    void set_Duration(double duration);
    void set_Rental_Cost(float rentalCost);
    void set_Replacement_Cost(float replacementCost);
    
    int get_Movie_ID();
    string get_Title();
    string get_Release_Date();
    string get_Rating();
    double get_Duration();
    float get_Rental_Cost();
    float get_Replacement_Cost();
    
    
    private:
    int Movie_ID;
    string Title;
    string ReleaseDate;
    string Rating;
    double Duration;
    float RentalCost;
    float ReplacementCost;
};
#endif
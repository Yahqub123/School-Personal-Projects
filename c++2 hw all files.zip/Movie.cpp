#include "Movie.h"
#include <string>
#include <iostream>
using namespace std;

Movie::Movie(){}
Movie::Movie(int Movie_iD, string title, string releaseDate, string rating, double duration, float rentalCost, float replacementCost)
{
    Movie_ID=Movie_iD;
    Title=title;
    ReleaseDate=releaseDate;
    Rating=rating;
    Duration=duration;
    RentalCost=rentalCost;
    ReplacementCost=replacementCost;
}


void Movie::set_Movie_ID(int Movie_iD)
{
    Movie_ID=Movie_iD;
}

void Movie::set_Title(string title)
{
    Title=title;
}

void Movie::set_Release_Date(string releaseDate)
{
    ReleaseDate=releaseDate;
}

void Movie::set_Rating(string rating)
{
    Rating=rating;
}

void Movie::set_Duration(double duration)
{
    Duration=duration;
}

void Movie::set_Rental_Cost(float rentalCost)
{
    RentalCost=rentalCost;
}

void Movie::set_Replacement_Cost(float replacementCost)
{
    ReplacementCost=replacementCost;
}

int Movie::get_Movie_ID()
{
    return Movie_ID;
}

string Movie::get_Title()
{
    return Title;
}

string Movie::get_Release_Date()
{
    return ReleaseDate;
}

string Movie::get_Rating()
{
    return Rating;
}

double Movie::get_Duration()
{
    return Duration;
}

float Movie::get_Rental_Cost()
{
    return RentalCost;
}

float Movie::get_Replacement_Cost()
{
    return ReplacementCost;
}
#include "Customer.h"
#ifndef CUSTOMERS_H
#define CUSTOMERS_H
#include <vector>
#include <string>
using namespace std;

class Customers
{
    public:
    void Add_customer();
    void Edit_customer();
    void Delete_customer();
    int Find_Customer();
    void Print_Customer_List();
    void Print_CustomerInfo(int found);
    void ListOfAll_LoansForMovie();
    void ListOfAll_LoansForcustomer();
    void ListOfLoansForAllCustomers();
    vector<Customer> Customer_List;
};
#endif
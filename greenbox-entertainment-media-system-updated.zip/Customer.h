#ifndef CUSTOMER_H
#define CUSTOMER_H
#include <string> 
using namespace std;
class Customer
{
    public:
    Customer();
    Customer(int CustomerId, long int CreditCardNum, string CustomerName, string CreditCardExpDate, int CreditCardValKey, unsigned int NumOfMoviesActive);
    
    void Set_CustomerId(int CustomerId);
    void Set_CreditCardNum(long int CreditCardNum);
    void Set_CustomerName(string CustomerName);
    void Set_CreditCardExpDate(string CreditCardExpDate);
    void Set_CreditCardValKey(int CreditCardValKey);
    void Set_NumOfMoviesActive(unsigned int NumOfMoviesActive);
    
    int get_CustomerId();
    long int get_CreditCardNum();
    string get_CustomerName();
    string get_CreditCardExpDate();
    int get_CreditCardValKey();
    int get_NumOfMoviesActive();
    
    
    private:
    int Customer_Id;
    long int Credit_CardNum;
    string Customer_Name;
    string Credit_Card_ExpDate;
    int Credit_Card_ValKey;
    unsigned int Num_Of_Movies_Active;
};
#endif 
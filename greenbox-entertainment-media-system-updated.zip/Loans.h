#include "Loan.h"
#ifndef LOANS_H
#define LOANS_H
#include <string>
#include <vector>
#include"Customers.h"
#include"Movies.h"
using namespace std;

class Loans
{
    public:
    void AddLoan(Customers&, Movies&);
    void EditLoan(Customers&, Movies&);
    void DeleteLoan(Customers&, Movies&);
    int FindLoan();
    void PrintLoanList();
    void PrintLoanInfo(int found);
    void ListOfAll_LoansForMovie();
    void LostOrOverdueMovie();
    void ListOfAll_LoansForcustomer();
    void ListOfAllLoans();
    void CheckedOutMovies();
    void CardTransactions();
    void FindMovie();
    vector <Loan>Loans;
};
#endif

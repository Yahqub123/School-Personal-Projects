#include "Movies.h"
#include "Customers.h"
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;
void Movies::AddMovie(ofstream& fin)
{
    unsigned int count;//Accepts num of movies to be added to the Movie_List
    int Movie_ID;
    string Title;
    string ReleaseDate;
    string Rating;
    double Duration;
    float RentalCost;
    float ReplacementCost;
    cout<<"How many Movies are you trying to add to the list?\n";
    cin>>count;
    for(int i=0; i<count; i++)
    {
        cout<<endl;
        cout<< "Enter the information for Movie "<< i+1 <<":\n";
        cout<< "What is the TITLE of the Movie that you wish to add? \n";
        cin.ignore();
        getline(cin,Title);
        cout<< "What is the ID of the Movie that you wish to add? \n";
        cin>>Movie_ID;
        cout<< "What is the Movie's Release Date? (mm/yyyy) \n";
        cin.ignore();
        getline(cin,ReleaseDate);
        cout<< "What is the Movie's rating? \n";
        getline(cin,Rating);
        cout<< "What is the Movie's Duration?(hh.mm) \n";
        cin>>Duration;
        cout<< "What is the Movie's Rental Cost? ($dd.cc)\n$";
        cin>>RentalCost;
        cout<< "What is the Movie's Replacement Cost? ($dd.cc)\n$";
        cin>>ReplacementCost;
        
        Movie ob = {Movie_ID, Title, ReleaseDate, Rating, Duration, RentalCost, ReplacementCost};
        Movie_List.push_back(ob);
        
        fin<<endl;
        fin<< "Movie "<<Movie_List.size()<< "'s Information are:\n"; 
        fin << "Movie id:" << Movie_List.at(Movie_List.size()-1).get_Movie_ID() <<endl;
        fin << "Movie Title: " << Movie_List.at(Movie_List.size()-1).get_Title()<<endl;
        fin << "Movie Release Date: " << Movie_List.at(Movie_List.size()-1).get_Release_Date()<<endl;
        fin << "Movie Rating: " << Movie_List.at(Movie_List.size()-1).get_Rating()<<endl;
        fin << "Movie Duration: " << Movie_List.at(Movie_List.size()-1).get_Duration()<<endl;
        fin << "Movie Rental Cost: $ " << Movie_List.at(Movie_List.size()-1).get_Rental_Cost()<<endl;
        fin << "Movie ReplacementCost: $ "<< Movie_List.at(Movie_List.size()-1).get_Replacement_Cost()<<endl;
    }

    //fin.close();
}

void Movies::EditMovie()
{
    int num,edit;
    int Movie_ID;
    string Title;
    string ReleaseDate;
    string Rating;
    double Duration;
    float RentalCost;
    float ReplacementCost;
    cout<< "Which Movie would you like to edit its information?(Enter INTEGER digits only. 1,2,3....e.t.c) \n";
    cin>> num;
    if(num>0){
    num=num-1;//reduced the size because vectors start from 0 not 1.
    }
    else if(num<0){
    cout<<"Invalid input. Only POSITIVE integers are acceptable.\n";
    }
    
    for(int i=0; i<Movie_List.size(); i++)
    {
        if(i==num)
        {
            cout<<"What would you like to edit about Movie " << i+1 <<"?\n";
            cout<<"Enter 1 to EDIT Movie's Title:\n";
            cout<<"Enter 2 to EDIT Movie's Id\n";
            cout<<"Enter 3 to EDIT Movie's Release Date: (mm/yyyy)\n";
            cout<<"Enter 4 to EDIT Movie's rating?\n";
            cout<<"Enter 5 to EDIT Movie's Duration?(hh.mm)\n";
            cout<<"Enter 6 to EDIT Movie's Rental Cost? ($dd.cc)\n";
            cout<<"Enter 7 to EDIT Movie's Replacement Cost? ($dd.cc)\n";
            cin.ignore();
            cin>> edit;
            switch(edit)
            {
                case 1:
                {
                    cout<<"Enter Movies's NEW TITLE: \n";
                    cin.ignore();
                    getline(cin,Title);
                    Movie_List.at(i).set_Title(Title);
                    break;
                }
                
                case 2:
                {
                    cout<<"Enter Movie's NEW Id: \n";
                    cin>>Movie_ID;
                    Movie_List.at(i).set_Movie_ID(Movie_ID);
                    break;
                }
                
                case 3:
                {
                    cout<< "Enter Movie's NEW Release Date? (mm/yyyy): \n";
                    cin.ignore();
                    getline(cin,ReleaseDate);
                    Movie_List.at(i).set_Release_Date(ReleaseDate);
                    break;
                }
                
                case 4:
                {
                    cout<< "Enter Movie's NEW rating:\n";
                    cin.ignore();
                    getline(cin,Rating);
                    Movie_List.at(i).set_Rating(Rating);
                    break;
                }
                
                case 5:
                {
                    cout<< "Enter Movie's NEW Duration: (hh.mm)\n";
                    cin>>Duration;
                    Movie_List.at(i).set_Duration(Duration);
                    break;
                }
                
                case 6:
                {
                    cout<< "Enter Movie's NEW Rental Cost? ($dd.cc):\n";
                    cin>>RentalCost;
                    Movie_List.at(i).set_Rental_Cost(RentalCost);
                    break;
                }
                
                case 7:
                {
                    cout<<"Enter Movie's NEW Replacement Cost ($dd.cc)\n";
                    cin>>ReplacementCost;
                    Movie_List.at(i).set_Replacement_Cost(ReplacementCost);
                    break;
                }
            }
        }
    }
    
    if(num+1>Movie_List.size()){
    cout<<"Movie Not found!\n";    
    }
    
    ofstream fin("GreenBoxData.txt");
    for(int i=0; i<Movie_List.size(); i++)
    {
        fin<<endl;
        fin<< "Movie "<<i+1<< "'s Information\n";
        fin << "Movie id: " <<Movie_List.at(i).get_Movie_ID() <<endl;
        fin << "Movie Title: " <<Movie_List.at(i).get_Title()<<endl;
        fin << "Movie Release Date" <<Movie_List.at(i).get_Release_Date()<<endl;
        fin << "Movie Rating: " <<Movie_List.at(i).get_Rating()<<endl;
        fin << "Movie Duration: " <<Movie_List.at(i).get_Duration()<<endl;
        fin << "Movie Rental Cost" <<Movie_List.at(i).get_Rental_Cost()<<endl;
        fin << "Movie ReplacementCost "<< Movie_List.at(i).get_Replacement_Cost()<<endl;
    }
    fin.close();
}

void Movies::DeleteMovie()
{
    int Num;
    cout<< "Which Movie would you would like to Delete Its Information? (Enter INTEGER digits only. 1,2,3....e.t.c): \n";
    cin.ignore();
    cin>>Num;
    if(Num>0){
        Num=Num - 1;
    }
    else if(Num<0){
        cout<<"Invalid input. Only POSITIVE integers are acceptable.\n";
    }
    for(int i=0; i<Movie_List.size(); i++)
    {
        if(Num==i)
        {
            Movie_List.erase(Movie_List.begin()+ i);
        }
    }
    if(Num+1 > Movie_List.size())
    {
        cout<<"Movie " <<Num + 1<<" does not exist in the list of Movies\n";
        cout<<"There are only "<< Movie_List.size() << " Movies in the List.\n";
    }
    
    ofstream fin("GreenBoxData.txt");
    for(int i=0; i<Movie_List.size(); i++)
    {
        fin<<endl;
        fin<< "Movie "<<i+1<< "'s Information\n";
        fin << "Movie id: " <<Movie_List.at(i).get_Movie_ID() <<endl;
        fin << "Movie Title: " <<Movie_List.at(i).get_Title()<<endl;
        fin << "Movie Release Date" <<Movie_List.at(i).get_Release_Date()<<endl;
        fin << "Movie Rating: " <<Movie_List.at(i).get_Rating()<<endl;
        fin << "Movie Duration: " <<Movie_List.at(i).get_Duration()<<endl;
        fin << "Movie Rental Cost" <<Movie_List.at(i).get_Rental_Cost()<<endl;
        fin << "Movie ReplacementCost "<< Movie_List.at(i).get_Replacement_Cost()<<endl;
    }
    fin.close();
}
/*
void::writetofile(ofstream&)
{
    //writes everyt
}*/
int Movies::FindMovie()
{
    string Title;
    int position=-1;
    cout<< "What is the Title of the Movie that you are Trying to find?\n";
    cin.ignore();
    getline(cin,Title);
    for(int i=0; i<Movie_List.size(); i++)
    {
        if(Title==Movie_List.at(i).get_Title())
        {
            cout<<"Movie found!\n";
            position=i;
        }
    }
    return position;
}

void Movies::PrintMovieList()
{
    cout<<endl;
    cout<<"Here's their information For all the Movies (If any) In the List:\n";
    for(int i=0; i<Movie_List.size(); i++)
    {
        cout<<"Here is all the information about Movie: "<< i+1 << endl;
        cout<<"Movie's Title: "<< Movie_List.at(i).get_Title() << endl;
        cout<<"Movie's Id: " << Movie_List.at(i).get_Movie_ID() <<endl;
        cout<<"Movie's Release Date (mm/yyyy): "<< Movie_List.at(i).get_Release_Date() << endl;
        cout<<"Movie's Rating: " << Movie_List.at(i).get_Rating() <<endl;
        cout<<"Movies Duration (hh.mm): " << Movie_List.at(i).get_Duration()<<endl;
        cout<<"Movie's Rental Cost ($dd.cc): " << Movie_List.at(i).get_Rental_Cost()<< endl;
        cout<<"Movie's Replacement Cost ($dd.cc): "<< Movie_List.at(i).get_Replacement_Cost() << endl;
        cout<<endl;
    }
}

void Movies::PrintMovieInfo(int found)
{
    cout<<endl;
    if(found>=0)
    {
        int i=found;
        cout<<"Here is all the information about Movie " << found + 1 << ":\n";
        cout<<"Movie's Title: "<< Movie_List.at(i).get_Title() << endl;
        cout<<"Movie's Id: " << Movie_List.at(i).get_Movie_ID() <<endl;
        cout<<"Movie's Release Date (mm/yyyy): "<< Movie_List.at(i).get_Release_Date() << endl;
        cout<<"Movie's Rating: " << Movie_List.at(i).get_Rating() <<endl;
        cout<<"Movies Duration (hh.mm): " << Movie_List.at(i).get_Duration()<<endl;
        cout<<"Movie's Rental Cost ($dd.cc): " << Movie_List.at(i).get_Rental_Cost()<< endl;
        cout<<"Movie's Replacement Cost ($dd.cc): "<< Movie_List.at(i).get_Replacement_Cost() << endl;
        cout<<endl;
    }
}
void Movies::ListOfAll_LoansForMovie()
{
}
    void Movies::ListOfAllMovieLoansForcustomer()
    {}
    void Movies::ListOfAllMovieLoans(){}
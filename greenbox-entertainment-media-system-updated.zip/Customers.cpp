#include "Customers.h"
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;


void Customers::Add_customer()
{
    unsigned int count;//Accepts num of values to be added to the Customer_List
    int num=0;
    int Customer_Id;
    long int Credit_CardNum;
    string Customer_Name;
    string Credit_Card_ExpDate;
    int Credit_Card_ValKey;
    unsigned int Num_Of_Movies_Active=0;
    cout<<"How many Customers are you trying to add to the list?\n";
    cin>>count;
    for(int i=0; i<count; i++)
    {
        cout<<endl;
        cout<< "Enter the information for Customer "<< i+1 <<":\n";
        cout<< "What is the Name of the customer that you wish to add? \n";
        cin.ignore();
        getline(cin,Customer_Name);
        cout<< "What is the ID of the customer that you wish to add? \n";
        cin>>Customer_Id;
        cout<< "What is the customer's credit card number? \n";
        cin>>Credit_CardNum;
        cout<< "What is the customer's Credit Card Expiration Date (mm/dd/yyyy)? \n";
        cin.ignore();
        getline(cin,Credit_Card_ExpDate);
        cout<< "What is the credit card's validation key (3 digits only)? \n";
        cin>>Credit_Card_ValKey;
        cout<< "How many movies do you have active? (max=2)\n";
        cin>>Num_Of_Movies_Active;
        while(Num_Of_Movies_Active>2)
        {
            cout<< "You cannot have more than 2 movies active. Enter a valid number:\n";
            cin>>Num_Of_Movies_Active;
        }

        Customer ob= Customer(Customer_Id, Credit_CardNum, Customer_Name, Credit_Card_ExpDate, Credit_Card_ValKey, Num_Of_Movies_Active);
        
        Customer_List.push_back(ob);
    }
    
    ofstream fin("GreenBoxData.txt");
    for(int i=0; i<Customer_List.size(); i++)
    {
        
        fin<<endl;
        fin<< "Customer "<<i+1<< "'s Information are:\n";
        fin << "Customer id: " <<Customer_List.at(i).get_CustomerId() <<endl;
        fin << "Customer Name: " <<Customer_List.at(i).get_CustomerName()<<endl;
        fin << "Customer Credit card num: " <<Customer_List.at(i).get_CreditCardNum()<<endl;
        fin << "Customer Credit card exp: " <<Customer_List.at(i).get_CreditCardExpDate()<<endl;
        fin << "Customer Credit card val key: " <<Customer_List.at(i).get_CreditCardValKey()<<endl;
        fin << "Customer Num of movies active: " <<Customer_List.at(i).get_NumOfMoviesActive()<<endl;
    }
    fin.close();
    
}

void Customers::Edit_customer()
{
    int num;
    int Customer_Id;
    long int Credit_CardNum;
    string Customer_Name;
    string Credit_Card_ExpDate;
    int Credit_Card_ValKey; 
    unsigned int Num_Of_Movies_Active;
    unsigned int edit;
    cout<< "Which customer would you like to edit their information?(Enter INTEGER digits only starting from 1,2,3....e.t.c) \n";
    cin>> num;
    
    if(num>0){
    num=num-1;//reduced the size because vectors start from 0 not 1.
    }
    else if(num<0){
    cout<<"Invalid input. Only POSITIVE integers are acceptable.\n";
    }
    
    for(int i=0; i<Customer_List.size(); i++)
    {
        if(i==num)
        {
            cout<<"What would you like to edit about customer " << i+1 << "?\n";
            cout<<"Enter 1 to EDIT Customer's name:\n";
            cout<<"Enter 2 to EDIT Customer's  Id\n";
            cout<<"Enter 3 to EDIT Customer credit card numbuer\n";
            cout<<"Enter 4 to EDIT Customer's credit card expiration date:\n";
            cout<<"Enter 5 to EDIT Customer's credit card validation key:\n";
            cout<<"Enter 6 to EDIT Customer's number of movies active:\n";
            cin.ignore();
            cin>> edit;
            switch(edit){
                case 1:
                {
                    cout<<"Enter customer's new name: \n";
                    cin.ignore();
                    getline(cin,Customer_Name);
                    Customer_List.at(i).Set_CustomerName(Customer_Name);
                    break;
                }
                
                case 2:
                {
                    cout<<"Enter Customer's new Id: \n";
                    cin>>Customer_Id;
                    Customer_List.at(i).Set_CustomerId(Customer_Id);
                    break;
                }
                
                case 3:
                {
                    cout<< "Enter Customer's new credit card num: \n";
                    cin>>Credit_CardNum;
                    Customer_List.at(i).Set_CreditCardNum(Credit_CardNum);
                    break;
                }
                
                case 4:
                {
                    cout<< "Enter Customers new credit card expiration date (mm/dd/yyyy):\n";
                    cin.ignore();
                    getline(cin,Credit_Card_ExpDate);
                    Customer_List.at(i).Set_CreditCardExpDate(Credit_Card_ExpDate);
                    break;
                }
                
                case 5:
                {
                    cout<< "Enter customers new credit card val key (3 digits):\n";
                    cin>>Credit_Card_ValKey;
                    Customer_List.at(i).Set_CreditCardValKey(Credit_Card_ValKey);
                    break;
                }
                
                case 6:
                {
                    cout<< "Enter the num of movies customer has active (max is 2):\n";
                    cin>>Num_Of_Movies_Active;
                    while(Num_Of_Movies_Active>2)
                    {
                        cout<< "You cannot have more than 2 movies active. Enter a valid number:\n";
                        cin>>Num_Of_Movies_Active;
                    }
                    Customer_List.at(i).Set_NumOfMoviesActive(Num_Of_Movies_Active);
                    break;
                }
            }
        }
    }
    
    num=num+1;
    if(num>Customer_List.size()){
    cout<<"Customer Not found!\n";    
    }
    
    ofstream fin("GreenBoxData.txt");
    for(int i=0; i<Customer_List.size(); i++)
    {
        fin<<endl;
        fin<< "Customer "<<i+1<< "'s Information are:\n";
        fin << "Customer id: " <<Customer_List.at(i).get_CustomerId() <<endl;
        fin << "Customer Name: " <<Customer_List.at(i).get_CustomerName()<<endl;
        fin << "Customer Credit card num: " <<Customer_List.at(i).get_CreditCardNum()<<endl;
        fin << "Customer Credit card exp: " <<Customer_List.at(i).get_CreditCardExpDate()<<endl;
        fin << "Customer Credit card val key: " <<Customer_List.at(i).get_CreditCardValKey()<<endl;
        fin << "Customer Num of movies active: " <<Customer_List.at(i).get_NumOfMoviesActive()<<endl;
    }
    fin.close();
}

void Customers::Delete_customer()
{
    int Num;
    cout<< "For which Customer would you would like to delete their information(Enter INTEGER digits only. 1,2,3....e.t.c): \n";
    cin.ignore();
    cin>>Num;
    if(Num>0){
        Num=Num - 1;
    }
    else if(Num<0){
        cout<<"Invalid input. Only POSITIVE integers are acceptable.\n";
    }
    for(int i=0; i<Customer_List.size(); i++)
    {
        if(Num==i)
        {
            Customer_List.erase(Customer_List.begin()+ i);
        }
    }
    if(Num+1 > Customer_List.size())
    {
        cout<<"Customer " <<Num + 1<<" does not exist in the list of Customers\n";
        cout<<"There are only "<< Customer_List.size() << " Customers in the List.\n";
    }
    
    ofstream fin("GreenBoxData.txt");
    for(int i=0; i<Customer_List.size(); i++)
    {
        fin<<endl;
        fin<< "Customer "<<i+1<< "'s Information are:\n";
        fin << "Customer id: " <<Customer_List.at(i).get_CustomerId() <<endl;
        fin << "Customer Name: " <<Customer_List.at(i).get_CustomerName()<<endl;
        fin << "Customer Credit card num: " <<Customer_List.at(i).get_CreditCardNum()<<endl;
        fin << "Customer Credit card exp: " <<Customer_List.at(i).get_CreditCardExpDate()<<endl;
        fin << "Customer Credit card val key: " <<Customer_List.at(i).get_CreditCardValKey()<<endl;
        fin << "Customer Num of movies active: " <<Customer_List.at(i).get_NumOfMoviesActive()<<endl;
    }
    fin.close();
}

int Customers::Find_Customer()
{
    string Name;
    int position=-1;
    cout<< "What is the NAME of the Customer that you are Trying to find?\n";
    cin.ignore();
    getline(cin,Name);
    for(int i=0; i<Customer_List.size(); i++)
    {
        if(Name==Customer_List.at(i).get_CustomerName())
        {
            cout<<"Customer found\n";
            position=i;
        }
    }
    if(position==-1)
    {
        cout<<"Customer " << Name<< " Not found!!\n";
    }
    return position;
}

void Customers::Print_Customer_List()
{
    cout<<endl;
    cout<<endl<<"Here's the information For all the Customers (If any) In the List:\n";
    for(int i=0; i<Customer_List.size(); i++)
    {
        cout<<"Here is all the information about Customer "<< i+1 << ":"<<endl;
        cout<<"Customer's Name: "<< Customer_List.at(i).get_CustomerName()<<endl;
        cout<<"Customer's ID: " << Customer_List.at(i).get_CustomerId()<<endl;
        cout<<"Customer's Credit Card Number: "<<Customer_List.at(i).get_CreditCardNum()<< endl;
        cout<<"Customer's Credit Card Expiration Date: " << Customer_List.at(i).get_CreditCardExpDate()<<endl;
        cout<<"Customer's Credit Card Validation Key: " <<Customer_List.at(i).get_CreditCardValKey()<<endl;
        cout<<"Number of Movies Active for Customer: " << Customer_List.at(i).get_NumOfMoviesActive()<< endl;
        cout<<endl;
    }
}


void Customers::Print_CustomerInfo(int found)
{
    cout<<endl;
    if(found>=0)
    {
        int i=found;
        cout<<"Here is all the information about the Customer we found:\n"; 
        cout<<"Customer's Name: "<< Customer_List.at(i).get_CustomerName()<<endl;
        cout<<"Customer's ID: " << Customer_List.at(i).get_CustomerId()<<endl;
        cout<<"Customer's Credit Card Number: "<<Customer_List.at(i).get_CreditCardNum()<< endl;
        cout<<"Customer's Credit Card Expiration Date: " << Customer_List.at(i).get_CreditCardExpDate()<<endl;
        cout<<"Customer's Credit Card Validation Key: " <<Customer_List.at(i).get_CreditCardValKey()<<endl;
        cout<<"Number of Movies Active for Customer: " << Customer_List.at(i).get_NumOfMoviesActive()<< endl;
        cout<<endl;
    }
}

void Customers::ListOfAll_LoansForMovie()
{
    string name;
    cout<<"Enter the Title of the Movie that you would like to see the Customers that loaned it: ";
    cin.ignore();
    getline(cin,name);
}
void Customers::ListOfAll_LoansForcustomer(){}
void Customers::ListOfLoansForAllCustomers(){}


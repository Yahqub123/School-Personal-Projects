#include "Movie.h"
#ifndef MOVIES_H
#define MOVIES_H
#include <vector>
#include <string>
using namespace std;

class Movies
{
    public:
    void AddMovie(ofstream&);
    void EditMovie();
    void DeleteMovie();
    void PrintMovieList();
    int FindMovie();
    void PrintMovieInfo(int found);
    void ListOfAll_LoansForMovie();
    void ListOfAllMovieLoansForcustomer();
    void ListOfAllMovieLoans();
    vector <Movie> Movie_List;
};
#endif
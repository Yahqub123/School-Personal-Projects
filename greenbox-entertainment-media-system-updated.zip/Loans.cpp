#include "Customer.h"
#include "Customers.h"
#include "Loan.h"
#include "Loans.h"
#include "Movie.h"
#include "Movies.h"
#include <string>
#include <vector>
#include <iostream>
using namespace std;

void Loans::AddLoan(Customers& ob, Movies& ob1)
{
    int found1,found2;//to check for the coditions before a loan can be placed.
    unsigned int count;//Accepts num of Loans to be added to the Loans list
    int LoanID;
    int MovieID;
    int CustomerID;
    string DueDate;
    string DueTime; 
    string Status;
    cout<<"How many Loans are you trying to add to the list?\n";
    cin>>count;
    for(int i=0; i<count; i++)
    {
        cout<<endl;
        cout<< "Enter the information for Loan "<< i+1 <<":\n";
        cout<< "What is the ID of the Loan that you wish to add? \n";
        cin>>LoanID;
        cout<< "What is the ID of the Movie that you wish to check out and add to the loan? \n";
        cin>>MovieID;
        cout<<"Here: "<< ob1.Movie_List.size()<<endl;//where my errors come from
        for(int i=0; i<ob1.Movie_List.size(); i++)
        {
            if(ob1.Movie_List.at(i).get_Movie_ID()==MovieID)
                {
                    cout<< "Movie exists and is available!\n";
                    MovieID=ob1.Movie_List.at(i).get_Movie_ID();
                    found1=1;
                }
                else
                {
                    found1=0;
                }
        }
        
        cout<< "What is the ID of the customer wanting to make a loan? \n";
        cin>>CustomerID;
        
        for(int i=0; i<ob.Customer_List.size(); i++)
        {
            if(ob.Customer_List.at(i).get_CustomerId()==CustomerID && ob.Customer_List.at(i).get_NumOfMoviesActive() <= 2)
            {
                cout<<"Customer exists and Customer does not have more than 2 movies active\n";
                CustomerID=ob.Customer_List.at(i).get_CustomerId();
                found2=1;
            }
            else
            {
                found2=0;
            }
        }
        cout<< "When is the loan due (mm/dd)(string)\n";
        cin.ignore();
        getline(cin,DueDate);
        cout<< "What TIME is the loan due? (hh.mm)(string)\n";
        getline(cin,DueTime);
        cout<< "What is the status of the Loan? \n";
        getline(cin,Status);

        if(found1==1 && found2==1)
        {
            Loan ob={LoanID, MovieID, CustomerID, DueDate, DueTime, Status};//creates an object and pushes its values in the loan vector.
            Loans.push_back(ob);
            cout<<"Loan has been successfully placed and added to the list!!\n";
        }
    }
    
    if(found1==0 || found2==0)
    {
        cout<<"MovieID: "<<MovieID<<endl;
        cout<<"CustomerID: "<<CustomerID<<endl;
        cout<<"Could not Add Loan to the list because:\n 1. Movie might not be found or available.\n 2. Customer has more than 2 movies checked out.\n ";
    }
}
    void Loans::EditLoan(Customers& ob, Movies& ob1){}
    void Loans::DeleteLoan(Customers& ob, Movies& ob1){}
    int Loans::FindLoan(){return 0;}
    void Loans::PrintLoanList(){}
    void Loans::PrintLoanInfo(int found){}
    void Loans::ListOfAll_LoansForMovie(){}
    void Loans::LostOrOverdueMovie(){}
    void Loans::ListOfAll_LoansForcustomer(){}
    void Loans::ListOfAllLoans(){}
    void Loans::CheckedOutMovies(){}
    void Loans::CardTransactions(){}
    void Loans::FindMovie(){}
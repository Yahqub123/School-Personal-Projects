install.packages('dplyr')
library(dplyr)
install.packages("dslabs")
library(dslabs)
data(murders)
head(murders)

#Adding Rate column to murders
murders <- mutate(murders, rate = total / population * 100000)

#Generate a new column named as population_in_millions, which is population/10^6
murders <- mutate(murders, population_in_millions = population / 10^6)

#If rank(x) gives you the ranks of x from lowest to highest, rank(-x) gives you the ranks from highest to lowest. 
#Use the function mutate to add a column rank containing the rank, from highest to lowest murder rate.
murders <- mutate(murders, rank = rank(-rate))

#Show the murder data for New York state.
filter(murders, state == "New York")

#See data from both New York and Texas
filter(murders, state %in% c("New York", "Texas"))

#Create a new data frame called no_florida with data except that of Florida state
no_florida <- filter(murders, state != "Florida")


#Create a new data frame called murders_nw with only the states from the Northeast and the West.
murders_nw <- filter(murders, region %in% c("Northeast ", " West "))

#Suppose you want to live in the Northeast or West and want the murder rate to be less than 1. We want to see the data for the states 
#satisfying these options. Note that you can use logical operators with filter. Here is an example in which we filter to keep only small 
#states in the Northeast region      
my_states <- filter(murders, region %in% c("Northeast","west") & rate < 1)
my_states
select(my_states,state,rate,rank)

#Practice Part 2

data(murders)
head(murders)
my_states <- murders %>% 
  mutate(murders, rate = total / population * 100000,rank = rank(-rate)) %>%
  filter(region %in% c("Northeast","west") & rate < 1) %>%
  select(state,rate,rank)
my_states

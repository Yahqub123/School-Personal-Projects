#include "Loan.h"
#include <string>
#include <iostream>
using namespace std;

Loan::Loan(){}

Loan::Loan(int loanID, int movieID, int customerID, string dueDate, double dueTime, string status)
{
    LoanID=loanID;
    MovieID=movieID;
    CustomerID=customerID;
    DueDate=dueDate;
    DueTime=dueTime;
    Status=status;
}

void Loan::Set_LoanID(int loanID)
{
    LoanID=loanID;
}

int Loan::get_LoanID()
{
    return LoanID;
}

void Loan::Set_MovieID(int movieID)
{
    MovieID=movieID;
}

int Loan::get_MovieID()
{
    return MovieID;
}

void Loan::Set_CustomerID(int customerID)
{
    CustomerID=customerID;
}

int Loan::get_CustomerID()
{
    return CustomerID;
}

void Loan::Set_DueDate(string dueDate)
{
    DueDate=dueDate;
}

string Loan::get_DueDate()
{
    return DueDate;
}

void Loan::Set_DueTime(double dueTime)
{
    DueTime=dueTime;
}

double Loan::get_DueTime()
{
    return DueTime;
}

void Loan::Set_Status(string status)
{
    Status=status;
}

string Loan::get_Status()
{
    return Status;
}

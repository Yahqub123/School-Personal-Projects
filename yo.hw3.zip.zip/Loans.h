#include "Loan.h"
#ifndef LOANS_H
#define LOANS_H
#include <string>
#include <vector>
#include"Customers.h"
#include"Ent_items.h"
using namespace std;

class Loans
{
    public:
    void AddLoan(Customers&, Ent_items&);
    void EditLoan(Customers&, Ent_items&);
    void DeleteLoan(Customers&, Ent_items&);
    int FindLoan();
    void PrintLoanList();
    void PrintLoanInfo(int found);
    void ListOfAll_LoansForMovie();
    void LostOrOverdueMovie();
    void ListOfAll_LoansForcustomer();
    void ListOfAllLoans();
    void CheckedOutMovies();
    void CardTransactions();
    void FindMovie();
    vector <Loan>Loans;
};
#endif


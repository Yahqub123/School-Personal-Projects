#include "Ent_item.h"
#include <iostream>
#include <string>
using namespace std;

Ent_item::Ent_item(){}//default constuctor.

Ent_item::Ent_item(int i,double j,string k ,int l)//Paramitized constructor.
{
    ID=i;
    cost=j;
    status=k;
    period=l;
}

void Ent_item::set_id(int id)
{
    ID=id;
}

int Ent_item::get_id()
{
    return ID;
}

void Ent_item::set_cost(double Cost)
{
    cost=Cost;
}

double Ent_item::get_cost()
{
    return cost;
}

void Ent_item::set_status(string Status)
{
    status=Status;
}

string Ent_item::get_status()
{
    return status;
}

void Ent_item::set_period(int loan)
{
    period=loan;
}

int Ent_item::get_period()
{
    return period;
}

void Ent_item::printitem()
{
    cout<<ID<<endl;
    cout<<cost<<endl;
    cout<<status<<endl;
    cout<<period<<endl;
}

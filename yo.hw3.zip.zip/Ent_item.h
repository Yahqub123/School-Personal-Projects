#ifndef ENT_ITEM_H
#define ENT_ITEM_H
#include <string>
using namespace std;

class Ent_item
{
    public:
    Ent_item();
    Ent_item(int,double,string,int);
    
    void set_id(int id);
    int get_id();
    
    void set_cost(double Cost);
    double get_cost();
    
    void set_status(string Status);
    string get_status();
    
    void set_period(int loan);
    int get_period();
    
    virtual void printitem();//virtual function
    
    private:
    int ID;
    double cost;
    string status;
    int period;
};
#endif

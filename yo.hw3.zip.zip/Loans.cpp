#include "Customer.h"
#include "Customers.h"
#include "Loan.h"
#include "Loans.h"
#include "Ent_item.h"
#include "Ent_items.h"
#include "Game.h"
#include "Movie.h"
#include <string>
#include <vector>
#include <iostream>
using namespace std;

void Loans::AddLoan(Customers& ob, Ent_items& ob1)
{ 
    int found1,found2;//to check for the coditions before a loan can be placed.
    int LoanID;
    int MovieID;
    int CustomerID;
    string DueDate;
    double DueTime; 
    string Status;

        cout<<endl;
        cout<< "What is the ID of the Loan that you wish to add? \n";
        cin>>LoanID;
        cout<< "What is the ID of the Movie that you wish to check out and add to the loan? \n";
        cin>>MovieID;
        for(int i=0; i<ob1.Movie_List.size(); i++)
        {
                if(ob1.Movie_List.at(i).get_id()==MovieID)
                {
                    cout<<"Movie exists and is available for loan!\n";
                    MovieID=ob1.Movie_List.at(i).get_id();
                    found1=1;
                }
                else if(ob1.Movie_List.at(i).get_id()!=MovieID)
                {
                    found1=0;
                }
        }
        
        cout<< "What is the ID of the customer wanting to make a loan? \n";
        cin>>CustomerID;
        
        for(int i=0; i<ob.Customer_List.size(); i++)
        {
            if(ob.Customer_List.at(i).get_CustomerId()==CustomerID && ob.Customer_List.at(i).get_NumOfMoviesActive() <= 2)
            {
                cout<<"Customer exists and Customer does not have more than 2 movies active\n";
                CustomerID=ob.Customer_List.at(i).get_CustomerId();
                found2=1;
            }
            else if(ob.Customer_List.at(i).get_CustomerId()!=CustomerID || ob.Customer_List.at(i).get_NumOfMoviesActive() > 2)
            {
                found2=0;
            }
        }
        cout<< "When is the loan due (mm/dd)(string)\n";
        cin.ignore();
        getline(cin,DueDate);
        cout<< "What TIME is the loan due? (hour.min)(24.00 is max)\n";
        cin>>DueTime;
        cout<< "What is the status of the Loan?(Out, In, Overdue, Lost) \n";
        cin.ignore();
        getline(cin,Status);

        if(found1==1 && found2==1)//checks if conditions were met and places loan
        {
            Loan ob={LoanID, MovieID, CustomerID, DueDate, DueTime, Status};//creates an object and pushes its values in the loan vector.
            Loans.push_back(ob);
            cout<<"Loan has been successfully placed and added to the list!!\n";
        }
        
        if(found1==0) //checks if conditions were met and states why loan could not be placed
        {
            cout<<"MovieID: "<<MovieID<<endl;
            cout<<"This Loan could not be placed and added to the list because:\n ";
            cout<<" ..Movie does not exist or movie isn't available\n";
        }
        
        if(found2==0)
        {
            cout<<"CustomerID: "<<CustomerID<<endl;
            cout<<"This Loan could not be placed and added to the list because:\n ";
            cout<<"..Customer does not exists or Customer has more than 2 movies active\n";
        }
}


void Loans::EditLoan(Customers& ob, Ent_items& ob1) 
{    
    int num,edit,found=0,found1=0,found2=0;
    int LoanID;
    int MovieID;
    int CustomerID;
    string DueDate;
    double DueTime; 
    string Status;
    cout<< "Enter the 'ID' of the Loan that you would  like to edit it's information?\n";
    cin>>num;

    for(int i=0; i<Loans.size(); i++)
    {
        if(num==Loans.at(i).get_LoanID())
        {
            cout<<"What would you like to edit about Loan: " <<num<< "?\n";
            cout<<"Enter 1 to EDIT Loan's ID:\n";
            cout<<"Enter 2 to EDIT the MOVIE ID for the Loan:\n";
            cout<<"Enter 3 to EDIT the CUSTOMER ID for the Loan\n";
            cout<<"Enter 4 to EDIT Loan's DUE DATE(string):\n";
            cout<<"Enter 5 to EDIT Loan's DUE TIME(hour.min)(24.00 is max):\n";
            cout<<"Enter 6 to EDIT Loan's Status:\n";
            cin>> edit;
            if(edit==1)
            {
                cout<<"Enter the new ID for the Loan:\n";
                cin>>LoanID;
                Loans.at(i).Set_LoanID(LoanID);
            }
            else if(edit==2)
            {
                cout<<"Enter the new MOVIE ID:\n";
                cin>>MovieID;
                for(int i=0; i<ob1.Movie_List.size(); i++)
                {
                    if(ob1.Movie_List.at(i).get_id()==MovieID)
                    {
                        Loans.at(i).Set_MovieID(MovieID);
                        found1=1;
                    }
                }
                
                if(found1==0)
                {
                    cout<<"The movie ID entered does not exist in the List of Movies available so it can't be set\n";
                }
            }
            else if(edit==3)
            {
                cout<<"Enter the new Customer ID:\n";
                cin>>CustomerID;
                for(int i=0; i<ob.Customer_List.size(); i++)
                {
                    if(ob.Customer_List.at(i).get_CustomerId()==CustomerID)
                    {
                        Loans.at(i).Set_CustomerID(CustomerID);
                        found2=1;
                    }
                }
                
                if(found2==0)
                {
                    cout<<"The Customer ID entered does not exist in the List of Customers so it can't be set\n";
                }
            }
            else if(edit==4)
            {
                cout<<"Enter Loan's new DUE DATE(string):\n";
                cin.ignore();
                getline(cin,DueDate);
                Loans.at(i).Set_DueDate(DueDate);
            }
            else if(edit==5)
            {
                cout<<"Enter Loan's new DUE TIME(hour.min)(24.00 is max):\n";
                cin>>DueTime;
                Loans.at(i).Set_DueTime(DueTime);
            }
            else if(edit==6)
            {
                cout<<"Enter Loan's new Status:\n";
                cin.ignore();
                getline(cin,Status);
                Loans.at(i).Set_Status(Status);
            }
            found=1;
        }
    }
    
    if(found=0)
    {
        cout<<"The Loan Id entered was not found in the list of Loans. Enter a valid Loan Id.";
    }
}
    
    
void Loans::DeleteLoan(Customers& ob, Ent_items& ob1)
{
    int LoanID;
    cout<<"What is the 'ID' of the LOAN that you wish to DELETE?\n";
    cin>>LoanID;
    for(int i=0; i<Loans.size(); i++)
    {
        if(Loans.at(i).get_LoanID()==LoanID)
        {
            Loans.erase(Loans.begin() + i);
        }
    }
}


int Loans::FindLoan()
{
    int LoanID, position=-1;
    cout<<"What is the 'ID' of the LOAN that you wish to FIND?\n";
    cin>>LoanID;
    for(int i=0; i<Loans.size(); i++)
    {
        if(Loans.at(i).get_LoanID()==LoanID)
        {
            cout<<"Loan was found!!\n";
            position=i;
        }
    }
    if(position==-1)
    {
        cout<<"Loan was not found.\n";
    }
    return position;
}


void Loans::PrintLoanList()
{
    cout<<endl<<endl<<"Here is all the information for all the Loans (If any) in the List.\n";
    for(int i=0; i<Loans.size(); i++)
    {
        cout<<"Here is the information for Loan "<<i+1<<":\n";
        cout<<"Loan ID: "<<Loans.at(i).get_LoanID()<<endl;
        cout<<"Movie ID: "<<Loans.at(i).get_MovieID()<<endl;
        cout<<"Customer ID: "<<Loans.at(i).get_CustomerID()<<endl;
        cout<<"Loan's Due Date: "<< Loans.at(i).get_DueDate()<<endl;
        cout<<"Loan's Due Time: " << Loans.at(i).get_DueTime()<<endl;
        cout<<"Loan's Status: " <<Loans.at(i).get_Status()<<endl<<endl;
    }
}


void Loans::PrintLoanInfo(int found)
{
    if(found>=0)
    {
        int i=found;

        cout<<"Here is the information for the Loan found:\n";
        cout<<"Loan ID: "<<Loans.at(i).get_LoanID()<<endl;
        cout<<"Movie ID: "<<Loans.at(i).get_MovieID()<<endl;
        cout<<"Customer ID: "<<Loans.at(i).get_CustomerID()<<endl;
        cout<<"Loan's Due Date: "<< Loans.at(i).get_DueDate()<<endl;
        cout<<"Loan's Due Time: " << Loans.at(i).get_DueTime()<<endl;
        cout<<"Loan's Status: " <<Loans.at(i).get_Status()<<endl<<endl;
    }
}


void Loans::ListOfAll_LoansForMovie()
{
    int MovieID;
    cout<<"Enter the 'ID' Of Movie that you are trying to see its Loans:\n";
    cin>>MovieID;
    cout<<"Here is the list of Loans (If any) for the Movie with the ID: "<<MovieID<<"\n";
    for(int i=0; i<Loans.size(); i++)
    {
        if(Loans.at(i).get_MovieID()==MovieID)
        {
            cout<<endl<<"Loan ID: "<<Loans.at(i).get_LoanID()<<endl;
            cout<<"Movie ID: "<<Loans.at(i).get_MovieID()<<endl;
            cout<<"Customer ID: "<<Loans.at(i).get_CustomerID()<<endl;
            cout<<"Loan's Due Date: "<< Loans.at(i).get_DueDate()<<endl;
            cout<<"Loan's Due Time: " << Loans.at(i).get_DueTime()<<endl;
            cout<<"Loan's Status: " <<Loans.at(i).get_Status()<<endl<<endl;
        }
    }
}


void Loans::ListOfAll_LoansForcustomer()
{
    int CustomerID;
    cout<<"Enter the 'ID' Of CUSTOMER that you are trying to see their Loans:\n";
    cin>>CustomerID;
    cout<<"Here is the list of Loans (If any) for the CUSTOMER with the ID: "<<CustomerID<<"\n";
    for(int i=0; i<Loans.size(); i++)
    {
        if(Loans.at(i).get_CustomerID()==CustomerID)
        {
            cout<<endl<<"Loan ID: "<<Loans.at(i).get_LoanID()<<endl;
            cout<<"Movie ID: "<<Loans.at(i).get_MovieID()<<endl;
            cout<<"Customer ID: "<<Loans.at(i).get_CustomerID()<<endl;
            cout<<"Loan's Due Date: "<< Loans.at(i).get_DueDate()<<endl;
            cout<<"Loan's Due Time: " << Loans.at(i).get_DueTime()<<endl;
            cout<<"Loan's Status: " <<Loans.at(i).get_Status()<<endl<<endl;
        }
    }
}
    void Loans::LostOrOverdueMovie(){}
    void Loans::ListOfAllLoans(){}
    void Loans::CheckedOutMovies(){}
    void Loans::CardTransactions(){}
    void Loans::FindMovie(){}
#include "Movie.h"
#include <string>
#include <iostream>
using namespace std;

Movie::Movie(){}
Movie::Movie(string title, string releaseDate, string rating, double duration, float rentalCost, float replacementCost,int i,double j,string k ,int l):Ent_item(i,j,k,l)
{
    Title=title;
    ReleaseDate=releaseDate;
    Rating=rating;
    Duration=duration;
    RentalCost=rentalCost;
    ReplacementCost=replacementCost;
}


void Movie::set_Title(string title)
{
    Title=title;
}

void Movie::set_Release_Date(string releaseDate)
{
    ReleaseDate=releaseDate;
}

void Movie::set_Rating(string rating)
{
    Rating=rating;
}

void Movie::set_Duration(double duration)
{
    Duration=duration;
}

void Movie::set_Rental_Cost(float rentalCost)
{
    RentalCost=rentalCost;
}

void Movie::set_Replacement_Cost(float replacementCost)
{
    ReplacementCost=replacementCost;
}


string Movie::get_Title()
{
    return Title;
}

string Movie::get_Release_Date()
{
    return ReleaseDate;
}

string Movie::get_Rating()
{
    return Rating;
}

double Movie::get_Duration()
{
    return Duration;
}

float Movie::get_Rental_Cost()
{
    return RentalCost;
}

float Movie::get_Replacement_Cost()
{
    return ReplacementCost;
}

void Movie::printitem()
{
    Ent_item::printitem();
}